package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.BoardCell;
import model.ClearCellGame;
import model.Game;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	
	@Test
	public void GameTest1() {
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		
		assertTrue(ccGame.getMaxRows() == 4 && ccGame.getMaxCols() == 5);
	}
	
	@Test
	public void GameTest2() {
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setBoardCell(0, 0, BoardCell.BLUE);
		
		assertTrue(ccGame.getBoardCell(0,0) == BoardCell.BLUE);
	}
	
	@Test
	public void GameTest3() {
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setRowWithColor(0, BoardCell.BLUE);
		
		assertTrue(ccGame.getBoardCell(0,0) == BoardCell.BLUE && 
				ccGame.getBoardCell(0,1) == BoardCell.BLUE &&
				ccGame.getBoardCell(0,2) == BoardCell.BLUE);
	}
	
	@Test
	public void GameTest4() {
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setColWithColor(0, BoardCell.BLUE);
		
		assertTrue(ccGame.getBoardCell(0,0) == BoardCell.BLUE && 
				ccGame.getBoardCell(1,0) == BoardCell.BLUE &&
				ccGame.getBoardCell(2,0) == BoardCell.BLUE);
	}
	
	@Test
	public void GameTest5() {
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setBoardWithColor(BoardCell.BLUE);
		
		assertTrue(ccGame.getBoardCell(0,0) == BoardCell.BLUE && 
				ccGame.getBoardCell(1,1) == BoardCell.BLUE &&
				ccGame.getBoardCell(2,2) == BoardCell.BLUE);
	}
	
	@Test
	public void ClearCellGameTest1() {		
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setBoardWithColor(BoardCell.BLUE);

		assertTrue(ccGame.isGameOver());
	}
	
	@Test
	public void ClearCellGameTest2() {		
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.nextAnimationStep();
		ccGame.nextAnimationStep();
		ccGame.nextAnimationStep();
		
		assertTrue(this.getBoardStr(ccGame).equals(
				"Board(Rows: 4, Columns: 5)\n"
				+ "RYBYB\n"
				+ "RRGYY\n"
				+ "RYBYR\n"
				+ ".....\n"));
	}
	
	@Test
	public void ClearCellGameTest3() {		
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setBoardWithColor(BoardCell.BLUE);
		ccGame.setRowWithColor(ccGame.getMaxRows() - 1, BoardCell.EMPTY);
		ccGame.setRowWithColor(1, BoardCell.YELLOW);
		ccGame.setBoardCell(1, ccGame.getMaxCols() - 1, BoardCell.RED);
		ccGame.setRowWithColor(3, BoardCell.EMPTY);

		ccGame.processCell(1, 3);

		assertTrue(this.getBoardStr(ccGame).equals(
				"Board(Rows: 4, Columns: 5)\n"
				+ "BBBBB\n"
				+ "....R\n"
				+ "BBBBB\n"
				+ ".....\n"));
	}
	
	@Test
	public void ClearCellGameTest4() {		
		Game ccGame = new ClearCellGame(4, 5, new Random(1L), 1);
		ccGame.setBoardWithColor(BoardCell.BLUE);
		ccGame.setRowWithColor(ccGame.getMaxRows() - 1, BoardCell.EMPTY);
		ccGame.setRowWithColor(1, BoardCell.YELLOW);
		ccGame.setBoardCell(1, ccGame.getMaxCols() - 1, BoardCell.RED);
		ccGame.setRowWithColor(3, BoardCell.EMPTY);

		ccGame.processCell(1, 3);
		ccGame.processCell(1, 4);
		
		assertTrue(this.getBoardStr(ccGame).equals(
				"Board(Rows: 4, Columns: 5)\n"
				+ "BBBBB\n"
				+ "BBBBB\n"
				+ ".....\n"
				+ ".....\n"));
	}
	
	private static String getBoardStr(Game game) {
		int maxRows = game.getMaxRows(), maxCols = game.getMaxCols();

		String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
		for (int row = 0; row < maxRows; row++) {
			for (int col = 0; col < maxCols; col++) {
				answer += game.getBoardCell(row, col).getName();
			}
			answer += "\n";
		}

		return answer;
	}
	
}
