package model;

import java.util.Random;

/**
 * This class extends GameModel and implements the logic of the clear cell game.
 * We define an empty cell as BoardCell.EMPTY. An empty row is defined as one
 * where every cell corresponds to BoardCell.EMPTY.
 * 
 * @author Department of Computer Science, UMCP
 */

public class ClearCellGame extends Game {
	private int strategy, score;
	private Random random;
	/**
	 * Defines a board with empty cells. It relies on the super class constructor to
	 * define the board. The random parameter is used for the generation of random
	 * cells. The strategy parameter defines which clearing cell strategy to use
	 * (for this project it will be 1). For fun, you can add your own strategy by
	 * using a value different that one.
	 * 
	 * @param maxRows
	 * @param maxCols
	 * @param random
	 * @param strategy
	 */
	public ClearCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols);
		this.random = random;
		this.strategy = strategy;
		this.score = 0;
	}

	/**
	 * The game is over when the last board row (row with index board.length -1) is
	 * different from empty row.
	 */
	public boolean isGameOver() {
		//checks for the last row being empty
		for(int i = 0; i < this.getMaxCols(); i++) {
			if(this.getBoardCell(this.board.length - 1, i) != BoardCell.EMPTY) {
				return true;
			}
		}
		return false;
	}

	public int getScore() {
		return this.score;
	}

	/**
	 * This method will attempt to insert a row of random BoardCell objects if the
	 * last board row (row with index board.length -1) corresponds to the empty row;
	 * otherwise no operation will take place.
	 */
	public void nextAnimationStep() {
		if(!this.isGameOver()) {
			
			//shifts the rows down by starting at the bottom and incrementing 
			//upwards.
			for(int i = this.getMaxRows() - 1; i > 0; i--) {
				for(int j = 0; j < this.getMaxCols(); j++) {
					this.board[i][j] = this.board[i - 1][j];
				}
			}
			
			//adds a random row at the top.
			for(int j = 0; j < this.getMaxCols(); j++) {
				this.board[0][j] = BoardCell.getNonEmptyRandomBoardCell(random);
			}
		}
	}

	/**
	 * This method will turn to BoardCell.EMPTY the cell selected and any adjacent
	 * surrounding cells in the vertical, horizontal, and diagonal directions that
	 * have the same color. The clearing of adjacent cells will continue as long as
	 * cells have a color that corresponds to the selected cell. Notice that the
	 * clearing process does not clear every single cell that surrounds a cell
	 * selected (only those found in the vertical, horizontal or diagonal
	 * directions).
	 * 
	 * IMPORTANT: Clearing a cell adds one point to the game's score.<br />
	 * <br />
	 * 
	 * If after processing cells, any rows in the board are empty,those rows will
	 * collapse, moving non-empty rows upward. For example, if we have the following
	 * board (an * represents an empty cell):<br />
	 * <br />
	 * RRR<br />
	 * GGG<br />
	 * YYY<br />
	 * * * *<br/>
	 * <br />
	 * then processing each cell of the second row will generate the following
	 * board<br />
	 * <br />
	 * RRR<br />
	 * YYY<br />
	 * * * *<br/>
	 * * * *<br/>
	 * <br />
	 * IMPORTANT: If the game has ended no action will take place.
	 * 
	 * 
	 */
	public void processCell(int rowIndex, int colIndex) {
		if(!this.isGameOver()) {
			
			//a and b record row and column indexes to be used for the rest of 
			//the comparisons without changing the original rowIndex and 
			//colIndex variables. 
			int a = rowIndex, b = colIndex;
			
			//checks the bounds for a and b, then checks for null exception, and
			//finally checks if the adjacent cell is the same color.
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a - 1][b - 1] 
					!= null && this.board[a - 1][b - 1] == 
					this.board[rowIndex][colIndex]) {
				
				//if the adjacent cell is the same color, changes it to empty
				this.board[a - 1][b - 1] = BoardCell.EMPTY;
				
				//increments a and b to reference a new block, then uses that 
				//as the base to check the next cell in the next iteration.
				a--;
				b--;
				score++;
			}
			
			//resets a and b to the original variables before checking a 
			//different direction. Once complete, does it again.
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a - 1][b] 
					!= null && this.board[a - 1][b] 
					== this.board[rowIndex][colIndex]) {
				this.board[a - 1][b] = BoardCell.EMPTY;
				a--;
				score++;
			}
			
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a - 1][b + 1] 
					!= null && this.board[a - 1][b + 1] 
					== this.board[rowIndex][colIndex]) {
				this.board[a - 1][b + 1] = BoardCell.EMPTY;
				a--;
				b++;
				score++;
			}
			
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a][b + 1] 
					!= null && this.board[a][b + 1] 
					== this.board[rowIndex][colIndex]) {
				this.board[a][b + 1] = BoardCell.EMPTY;
				b++;
				score++;
			}
			
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a + 1][b + 1] 
					!= null && this.board[a + 1][b + 1] 
					== this.board[rowIndex][colIndex]) {
				this.board[a + 1][b + 1] = BoardCell.EMPTY;
				a++;
				b++;
				score++;
			}
			
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a + 1][b] 
					!= null && this.board[a + 1][b] 
					== this.board[rowIndex][colIndex]) {
				this.board[a + 1][b] = BoardCell.EMPTY;
				a++;
				score++;
			}
			
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a + 1][b - 1] 
					!= null && this.board[a + 1][b - 1] 
					== this.board[rowIndex][colIndex]) {
				this.board[a + 1][b - 1] = BoardCell.EMPTY;
				a++;
				b--;
				score++;
			}
			
			a = rowIndex;
			b = colIndex;
			while(a > 0 && a < this.getMaxRows() - 1 && b > 0 && 
					b < this.getMaxCols() - 1 && this.board[a][b - 1] 
					!= null && this.board[a][b - 1] 
					== this.board[rowIndex][colIndex]) {
				this.board[a][b - 1] = BoardCell.EMPTY;
				b--;
				score++;
			}
			
			//makes the original cell empty at the end
			this.board[rowIndex][colIndex] = BoardCell.EMPTY;
		
			//uses a boolean to check whether the rows shift or not.
			boolean shift = false;
			
			//count for the empty cells, and c is the row in which the cells 
			//should begin incrementing.
			int count = 0, c = 0;
			for(int i = 0; i < this.getMaxRows() - 1; i++) {
				count = 0;
				for(int j = 0; j < this.getMaxCols(); j++) {
					
					//adds a count for each non empty cell
					if(this.board[i][j] != BoardCell.EMPTY) {
						count++;
					}
				}
				
				//if a cell was not empty, the count will be greater than 0. 
				//Sets the variable c to the row index of the first shift.
				if(count == 0) {
					shift = true;
					c = i;
				}
			}
			
			//if the shift is confirmed through the previous for loop, sets the 
			//row to the next row until the bottom of the array.
			if(shift) {
				for(int i = c; i < this.getMaxRows() - 1; i++) {
					for(int j = 0; j < this.getMaxCols(); j++) {
						this.board[i][j] = this.board[i + 1][j];
					}
				}
			}	
		}
	}
}