package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.Test;

import tubeVideosManager.Genre;
import tubeVideosManager.Playlist;
import tubeVideosManager.TubeVideosManager;
import tubeVideosManager.Video;

/**
 * 
 * You need student tests if you are asking for help during
 * office hours about bugs in your code. Feel free to use
 * tools available in TestingSupport.java
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void PlaylistConstructorTest1() {
		Playlist p1 = new Playlist("Songs");
		
		assertTrue(p1.toString().equals("Playlist Name: Songs\nVideoTitles: "
				+ "[]"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void PlaylistConstructorTest2() {
		Playlist p1 = new Playlist("");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void PlaylistConstructorTest3() {
		String name = null;
		Playlist p1 = new Playlist(name);
	}
	
	@Test
	public void PlaylistGetNameTest() {
		Playlist p1 = new Playlist("Songs");
		
		assertTrue(p1.getName().equals("Songs"));
	}
	
	@Test
	public void PlaylistCopyConstructorTest() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");

		Playlist p2 = new Playlist(p1);
		
		assertTrue(p2.toString().equals("Playlist Name: Songs\nVideoTitles: "
				+ "[Song1, Song2]"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void PlaylistAddToPlaylistTest1() {
		Playlist p1 = new Playlist("Songs");
		
		p1.addToPlaylist(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void PlaylistAddToPlaylistTest2() {
		Playlist p1 = new Playlist("Songs");
		
		p1.addToPlaylist("");
	}
	
	@Test
	public void PlaylistGetPlaylistVideosTitlesTest() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");

		String answer = p1.getPlaylistVideosTitles() + "";
		assertTrue(answer.equals("[Song1, Song2]"));
	}
	
	@Test
	public void PlaylistRemoveAllFromPlaylistTest1() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");
		
		p1.removeFromPlaylistAll("Song1");

		String answer = p1.getPlaylistVideosTitles() + "";
		assertTrue(answer.equals("[Song2]"));
	}
	
	@Test
	public void PlaylistRemoveAllFromPlaylistTest2() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");
		
		assertTrue(p1.removeFromPlaylistAll("Song3") == false);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void PlaylistRemoveAllFromPlaylistTest3() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");
		
		p1.removeFromPlaylistAll("");	
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void PlaylistRemoveAllFromPlaylistTest4() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");
		
		p1.removeFromPlaylistAll(null);	
	}
	
	@Test
	public void PlaylistShuffleVideoTitlesTest1() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");
		p1.addToPlaylist("Song3");
		p1.addToPlaylist("Song4");
		p1.addToPlaylist("Song5");
		p1.addToPlaylist("Song6");
		
		p1.shuffleVideoTitles(null);
		String answer = p1.getPlaylistVideosTitles() + "";
		
		assertTrue(!(answer.equals("[Song1, Song2, Song3, Song4, Song5, "
				+ "Song6]")));
	}
	
	@Test
	public void PlaylistShuffleVideoTitlesTest2() {
		Playlist p1 = new Playlist("Songs");
		p1.addToPlaylist("Song1");
		p1.addToPlaylist("Song2");
		p1.addToPlaylist("Song3");
		p1.addToPlaylist("Song4");
		p1.addToPlaylist("Song5");
		p1.addToPlaylist("Song6");
		
		p1.shuffleVideoTitles(new Random(3));
		String answer = p1.getPlaylistVideosTitles() + "";

		assertTrue(answer.equals("[Song6, Song4, Song2, Song5, Song1, Song3]"));
	}
	
	@Test
	public void VideoConstructorTest1() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		
		assertEquals(v1.toString(),"Title: \"How to Draw in Java Tutorial\"\n"
				+ "Url: https://www.youtube.com/embed/ifVf9ejuFWI\n"
				+ "Duration (minutes): 17\nGenre: Educational\n");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest2() {
		Video v1 = new Video(null, "https://www.youtube.com/embed/ifVf9ejuFWI", 
				17, Genre.Educational);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest3() {
		Video v1 = new Video("", "https://www.youtube.com/embed/ifVf9ejuFWI", 
				17, Genre.Educational);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest4() {
		Video v1 = new Video("How to Draw in Java Tutorial", null, 17,
				Genre.Educational);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest5() {
		Video v1 = new Video("How to Draw in Java Tutorial", "", 17, 
				Genre.Educational);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest6() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", -1, 
				Genre.Educational);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest7() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 0, 
				Genre.Educational);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoConstructorTest8() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, null);
	}
	
	@Test
	public void VideoCopyConstructorTest() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		v1.addComments("First Comment");
		
		Video v2 = new Video(v1);
		String answer = v1.toString() + v2.getComments();
		
		assertEquals(answer,"Title: \"How to Draw in Java Tutorial\"\n"
				+ "Url: https://www.youtube.com/embed/ifVf9ejuFWI\n"
				+ "Duration (minutes): 17\nGenre: Educational\n" 
				+ "[First Comment]");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoAddCommentsTest1() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		v1.addComments(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void VideoAddCommentsTest2() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		v1.addComments("");
	}

	@Test
	public void VideoCompareToTest1() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Video v2 = new Video("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);

		assertTrue(v1.compareTo(v2) > 0);
	}
	
	@Test
	public void VideoCompareToTest2() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Video v2 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);

		assertTrue(v1.compareTo(v2) == 0);
	}
	
	@Test
	public void VideoEqualsTest1() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Video v2 = new Video("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);

		assertTrue(!(v1.equals(v2)));
	}
	
	@Test
	public void VideoEqualsTest2() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Video v2 = new Video("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);

		assertTrue(v1.equals(v1));
	}
	
	@Test
	public void VideoEqualsTest3() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Video v2 = new Video("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);

		assertTrue(!(v1.equals(null)));
	}
	
	@Test
	public void VideoEqualsTest4() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Video v2 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);

		assertTrue(v1.equals(v2));
	}
	
	@Test
	public void VideoEqualsTest5() {
		Video v1 = new Video("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		Playlist p1 = new Playlist("Songs");

		assertTrue(!(v1.equals(p1)));
	}
	
	@Test
	public void TubeVideosManagerAddVideoToDBTest() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		String answer = t1.getAllVideosInDB() + "";
		assertEquals(answer,"[Title: \"How to Draw in Java Tutorial\"\n"
				+ "Url: https://www.youtube.com/embed/ifVf9ejuFWI\n"
				+ "Duration (minutes): 17\n"
				+ "Genre: Educational\n"
				+ ", Title: \"Git & GitHub Crash Course for Beginners\"\n"
				+ "Url: https://www.youtube.com/embed/SWYqp7iY_Tc\n"
				+ "Duration (minutes): 33\n"
				+ "Genre: Educational\n"
				+ "]");
	}
	
	@Test
	public void TubeVideosManagerFindVideoTest1() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		String answer = t1.findVideo("How to Draw in Java Tutorial").toString();
		
		assertEquals(answer,"Title: \"How to Draw in Java Tutorial\"\n"
				+ "Url: https://www.youtube.com/embed/ifVf9ejuFWI\n"
				+ "Duration (minutes): 17\n"
				+ "Genre: Educational\n");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void TubeVideosManagerFindVideoTest2() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		t1.findVideo("");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void TubeVideosManagerFindVideoTest3() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		t1.findVideo(null);
	}
	
	@Test
	public void TubeVideosManagerAddCommentsTest1() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		t1.addComments("How to Draw in Java Tutorial","Great Video");
		
		String answer = t1.findVideo("How to Draw in Java Tutorial")
				.getComments() + "";
		
		assertEquals(answer,"[Great Video]");
	}
	
	@Test
	public void TubeVideosManagerAddCommentsTest2() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		boolean answer = t1.addComments("How to Draw in Java Tutorial","");
		
		assertTrue(!answer);
	}
	
	@Test
	public void TubeVideosManagerAddCommentsTest3() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		boolean answer = t1.addComments("How to Draw in Java Tutorial",null);
		
		assertTrue(!answer);
	}
	
	@Test
	public void TubeVideosManagerAddCommentsTest4() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		boolean answer = t1.addComments("","Great Video");
		
		assertTrue(!answer);
	}
	
	@Test
	public void TubeVideosManagerAddCommentsTest5() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		
		boolean answer = t1.addComments(null,"Great Video");
		
		assertTrue(!answer);
	}
	
	@Test
	public void TubeVideosManagerGetPlaylistsNamesTest1() {
		TubeVideosManager t1 = new TubeVideosManager();
		String answer = "";
		String[] temp = t1.getPlaylistsNames();
		
		for(int i = 0; i < temp.length; i++) {
			answer += temp[i];
		}
		
		assertEquals(answer,"");
	}
	
	@Test
	public void TubeVideosManagerAddVideoToPlaylistTest1() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		t1.addPlaylist("Educational Videos");
		t1.addVideoToPlaylist("How to Draw in Java Tutorial", 
				"Educational Videos");
		
		String answer = "";
		answer += t1.getPlaylist("Educational Videos")
				.getPlaylistVideosTitles();
		
		assertEquals(answer,"[How to Draw in Java Tutorial]");
	}
	
	@Test
	public void TubeVideosManagerAddVideoToPlaylistTest2() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		t1.addPlaylist("Educational Videos");
		
		boolean answer = t1.addVideoToPlaylist("How to Draw in Java Tutorial", 
				"Sports");;
		
		assertTrue(!answer);
	}
	
	@Test
	public void TubeVideosManagerAddVideoToPlaylistTest3() {
		TubeVideosManager t1 = new TubeVideosManager();
		t1.addVideoToDB("How to Draw in Java Tutorial", 
				"https://www.youtube.com/embed/ifVf9ejuFWI", 17, 
				Genre.Educational);
		t1.addVideoToDB("Git & GitHub Crash Course for Beginners", 
				"https://www.youtube.com/embed/SWYqp7iY_Tc", 33, 
				Genre.Educational);
		t1.addPlaylist("Educational Videos");
		
		boolean answer = t1.addVideoToPlaylist("How to Draw", 
				"Educational Videos");;
		
		assertTrue(!answer);
	}
}
