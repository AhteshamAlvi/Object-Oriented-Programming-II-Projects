package tests;

import static org.junit.Assert.*;

import java.util.Comparator;
import java.util.NoSuchElementException;

import org.junit.Test;

import listClasses.BasicLinkedList;
import listClasses.SortedLinkedList;

/**
 * 
 * You need student tests if you are looking for help during office hours about
 * bugs in your code.
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {
	
	/*
	 * Test to check if the addToEnd, addToFront and getFirst methods work. Adds
	 * three elements to the list, and checks the first element.
	 */
	@Test
	public void BasicLinkedListTestAdd1() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();

		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		
		assertEquals("Blue",basicList.getFirst());
	}
	
	/*
	 * Additional test to check if the addToEnd, addToFront and getLast methods 
	 * work. Adds three elements to the list, and checks the last element.
	 */
	@Test
	public void BasicLinkedListTestAdd2() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();

		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");

		assertEquals("Red",basicList.getLast());
	}
	
	/*
	 * Testing the retrieveFirstElement method. Retrieves the first element to 
	 * and sets its value to the answer string, then checks the new first 
	 * element by adding it the answer string.
	 */
	@Test
	public void BasicLinkedListTestRetrieveFirst() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		String answer = basicList.retrieveFirstElement();
		
		assertEquals("BlueYellow", answer + basicList.getFirst());
	}
	
	/*
	 * Testing the retrieveLastElement method. Retrieves the last element to 
	 * and sets its value to the answer string, then checks the new last 
	 * element by adding it the answer string.
	 */
	@Test
	public void BasicLinkedListTestRetrieveLast() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();

		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		String answer = basicList.retrieveLastElement();

		assertEquals("RedYellow", answer + basicList.getLast());

	}
	
	/*
	 * Testing the remove method. Removes the last element in the linked list, 
	 * and then gets the new last element and checks if it is the original
	 * middle element
	 */
	@Test
	public void BasicLinkedListTestRemove() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		
		
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		basicList.remove​("Red", String.CASE_INSENSITIVE_ORDER);
		
		assertEquals("Yellow", basicList.getLast());
	}
	
	/*
	 * Testing the iterator for the basicList. Adds three elements and iterates
	 * through them to add to a string then checks the value of the string.
	 */
	@Test
	public void BasicLinkedListTestIterator1() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		String answer = "";
		
		for (String entry : basicList) {
			answer += entry + " ";
		}
		
		assertEquals("Blue Yellow Red ", answer);
	}
	
	
	/*
	 * Testing the iterator next() method for the exception. Assigns no elements 
	 * to a list and checks for the exception to be triggered.
	 */
	@Test(expected = NoSuchElementException.class)
	public void BasicLinkedListTestIterator2() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();

		basicList.iterator().next();
	}
	
	/*
	 * Testing the getReversedArrayList by setting the arrayList to a string and
	 * checking the value of the list after calling the reverse method.
	 */
	@Test
	public void BasicLinkedListTestGetReverseArrayList() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();

		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		String answer = "" + basicList.getReverseArrayList();
		assertEquals("[Red, Yellow, Blue]", answer);
	}
	
	/*
	 * Testing the getReversedList by creating a new list and setting it to the 
	 * return of the method getReverseList. Then retrieves the first elements to
	 * an answer string and checks the value of the string.
	 */
	@Test
	public void BasicLinkedListTestGetReverseList() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");

		BasicLinkedList<String> reverse = basicList.getReverseList();
		String answer = "";

		answer += reverse.retrieveFirstElement() + " ";
		answer += reverse.retrieveFirstElement() + " ";
		answer += reverse.retrieveFirstElement();
		
		assertEquals("Red Yellow Blue", answer);
	}
	
	/*
	 * Checks the sorted list add method by adding three elements in an incorrect
	 * order then checking for the first element.
	 */
	@Test
	public void SortedLinkedListTestAdd() {
		SortedLinkedList<String> sortedList = 
				new SortedLinkedList<String>(String.CASE_INSENSITIVE_ORDER);

		sortedList.add​("Yellow").add​("Blue").add​("Red");
		
		assertEquals("Blue",sortedList.getFirst());
	}
	
	/*
	 * Testing the iterator and order for the sortedList. Adds three elements
	 * and iterates through them to add to a string then checks the value of 
	 * the string.
	 */
	@Test
	public void SortedLinkedListTestIterator() {
		SortedLinkedList<String> sortedList = 
				new SortedLinkedList<String>(String.CASE_INSENSITIVE_ORDER);
		sortedList.add​("Yellow").add​("Blue").add​("Red");
		String answer = "";
		
		for (String entry : sortedList) {
			answer += entry + " ";
		}
		
		assertEquals("Blue Red Yellow ", answer);
	}
	
	/*
	 * Checks the sorted list remove method by adding three elements in an 
	 * incorrect order, and then removing the first one. Then checks the first
	 * element.
	 */
	@Test
	public void SortedLinkedListTestRemove() {
		SortedLinkedList<String> sortedList = 
				new SortedLinkedList<String>(String.CASE_INSENSITIVE_ORDER);

		sortedList.add​("Yellow").add​("Blue").add​("Red");
		sortedList.remove​("Blue");
		
		assertEquals("Red",sortedList.getFirst());
	}

}
