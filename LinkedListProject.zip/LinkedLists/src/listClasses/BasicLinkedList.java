package listClasses;

import java.util.*;


public class BasicLinkedList<T> implements Iterable<T> {
	
	/* Node definition */
	protected class Node {
		protected T data;
		protected Node next;

		protected Node(T data) {
			this.data = data;
			next = null;
		}
	}

	/* We have both head and tail */
	protected Node head, tail;
	
	/* size */
	protected int listSize;
	
	public BasicLinkedList() {
		head = null;
		tail = null;
		listSize = 0;
	}

	//Returns the size value of the list.
	public int getSize() {
		return this.listSize;
	}
	
	//Adds each element onto the end of the list.
	public BasicLinkedList<T> addToEnd(T data) {
		//Makes a new node with the data provided.
		Node newNode = new Node(data);

		//Checks if the last element is null, meaning the list is empty.
		if(tail == null) {
			
			//If its empty, sets the new element to both the head and tail.
			head = newNode;
			tail = newNode;
		} else {
			
			//If it isn't empty, it sets the new tail to the new node.
			tail.next = newNode;
			tail = tail.next;
		}
		
		//Increments the list size and returns a reference to the object.
		listSize++;
		return this;
	}
	
	//Adds an element to the front of the list.
	public BasicLinkedList<T> addToFront(T data) {
		//Makes a new node with the data provided.
		Node newNode = new Node(data);
		
		/*
		 * Points the new node's next reference to the head of the list, and 
		 * then sets head to the new node.
		 */
		newNode.next = head;
		head = newNode;
		
		/*
		 * Checks if the last node is null, meaning the list is empty, and if so
		 * sets the tail to the new node as well.
		 */
		if(tail == null) {
			tail = newNode;
		}
		
		//Increments the list size and returns a reference to the object.
		listSize++;
		return this;
	}
	
	//Returns the data on the first element in the list.
	public T getFirst() {
		//Checks if the head is null and the list is empty and returns null.
		if(head == null) {
			return null;
		}
		
		//Returns the data assigned to the head node.
		return head.data;
	}

	//Returns the data on the last element in the list.
	public T getLast() {
		//Checks if the tail is null and the list is empty and returns null.
		if(tail == null) {
			return null;
		}
		
		//Returns the data assigned to the tail node.
		return tail.data;
	}
	
	//Returns the data of the first element, and then removes it from the list.
	public T retrieveFirstElement() {
		//Checks if the head is null and the list is empty and returns null.
		if(head ==  null) {
			return null;
		}
		
		/*
		 * Creates a current reference to the head node, then increments the 
		 * head to point to the next node in the list, thus removing the first 
		 * node.
		 */
		Node curr = head;
		head = head.next;		
		
		/*
		 * Checks if the head is null, and if so sets the tail to null, meaning 
		 * there was only one element and now the list is empty.
		 */
		if(head == null) {
			tail = null;
		}
		
		/*
		 * Increments the list size and returns the data assigned to the 
		 * original head element.
		 */
		listSize--;
		return curr.data;
	}
	
	//Returns the data of the last element, and then removes it from the list.
	public T retrieveLastElement() {
		//Checks if the tail is null and the list is empty and returns null.
		if(tail ==  null) {
			return null;
		}
		
		//Creates a temporary reference to the tail node.
		Node temp = tail;
		
		/*
		 * Checks if the head and tail are the same, meaning there is only one
		 * element in the list.
		 */
		if(head == tail) {
			//If so, sets both the head and tail to null, emptying the list.
			head = null;
			tail = null;
		} else {
			/*
			 * Creates a previous and current reference, setting the current 
			 * reference to the head node.
			 */
			Node prev = null, curr = head;
			
			/*
			 * Increments the previous and current references to the end of the 
			 * list by making sure the current references next reference is not
			 * null.
			 */
			while(curr.next != null) {
				prev = curr;
				curr = curr.next;
			}
			
			/*
			 * After reaching the end of the list, sets the tail of the list to
			 * the previous reference to remove the current referenced node from 
			 * the list.
			 */
			tail = prev;
		}
		
		/*
		 * Increments the list size and returns the data assigned to the 
		 * original tail element.
		 */
		listSize--;
		return temp.data;
	}

	//Removes the target node from the list through comparing its data.
	public BasicLinkedList<T> remove​(T targetData, Comparator<T> comparator) {
		/*
		 * Creates a previous and current reference, setting the current 
		 * reference to the head node.
		 */
		Node prev = null, curr = head;
		 
		/*
		 * Iterates through the list by incrementing till the current reference 
		 * is null.
		 */
		while(curr != null) {
			/*
			 * Checks if the current reference data and the target data are the 
			 * same using the comparators compare method.
			 */
			if(comparator.compare(curr.data, targetData) == 0) {
				
				/*
				 * Checks if the previous reference is null, in which case the 
				 * node to be removed is the first on the list, meaning the head
				 * node needs to be incremented to the current node's next 
				 * reference.
				 */
				if(prev == null) {
					//Sets the head to the current node's next reference.
					curr = curr.next;
					head = curr;
				} else {
					/*
					 * Sets the previous node's next reference to the
					 * current node's next reference, effectively skipping over 
					 * a node and removing it from the list.
					 */
					prev.next = curr.next;
				}
				
				/*
				 * If the current node references the tail, then it removes the 
				 * tail and sets the tail to the previous node.
				 */
				if(curr == tail) {
					tail = prev;
				}
				//Increments the list size.
				listSize--;				
			} else {
				/*
				 * Sets the previous node to the current node if the current 
				 * node is not the node to be replaced.
				 */
				prev = curr;
			}
			//Increments the current node to the next node to iterate the list.
			curr = curr.next;
		}
		//Returns a reference to the current object.
		return this;
	}

	//Iterates the list.
	@Override
	public Iterator<T> iterator() {
		return new Iterator<T>(){
			//Creates a current reference to the head node.
			Node curr = head;
			
			//Checks if the current node is null. if so returns false.
			@Override
			public boolean hasNext() {
				if(curr == null) {
					return false;
				}
				return true;
			}
			
			/*
			 * Increments the list if the hasNext() method returns true and 
			 * there is a current reference that is not null.
			 */
			@Override
			public T next() {
				if(!hasNext()) {
					throw new NoSuchElementException();
				}
				
				/*
				 * Creates a temporary reference to the current node to record 
				 * its data.
				 */
				Node temp = curr;
				//Increments the current reference to the next node.
				curr = curr.next;
				//Returns the recorded data in the temporary reference.
				return temp.data;
			}
			
			//Remove method override not required.
			@Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
		};
	}
	
	/*
	 * Creates an arrayList and recursively reverses the linked list into the 
	 * arrayList then returns the arrayList.
	 */
	public ArrayList<T> getReverseArrayList() {
		//creates the arrayList for the reversed values
		ArrayList<T> answer = new ArrayList<>();

		/*
		 * Calling of the auxiliary method that uses the head of the list and 
		 * the answer arrayList as parameters.
		 */
		getReverseArrayListAux(head, answer);
		
		//Returns the final arrayList.
		return answer;
	}
	
	//The auxiliary method to the recursive getReverseArrayList method.
	public void getReverseArrayListAux(Node headAux, ArrayList<T> answerAux) {
		//Checks if the head is null and the list is empty.
		if(headAux != null) {
			/*
			 * Recursive call of the auxiliary method using the next iteration 
			 * of the linked list. Iterates the head to the next node and inputs 
			 * it as the parameter.
			 */
			getReverseArrayListAux(headAux.next, answerAux);
			/*
			 * Adds the head node data to the arrayList. Since it is done after
			 * the recursive call, it adds in reverse since it will all be 
			 * counted at the end once the recursive method finishes iterating.
			 */
			answerAux.add(headAux.data);
		}
		//Return to break.
		return;
	}

	/*
	 * Creates a new linked list and recursively reverses the linked list into 
	 * the new list then returns the list reference.
	 */
	public BasicLinkedList<T> getReverseList() {
		//Creates a new list reference called reversal.
		BasicLinkedList<T> reversal = new BasicLinkedList<>();
		
		/*
		 * Calling of the auxiliary method that uses the head of the list and 
		 * the reversal new linked list as parameters.
		 */
		getReverseListAux(head, reversal);
		
		//Returns the final linked list.
		return reversal;
	}
	
	//The auxiliary method to the recursive getReverseList method.
	public void getReverseListAux(Node newHead, BasicLinkedList<T> reversal) {
		//Checks if the head is null and the list is empty.
		if(newHead != null) {
			/*
			 * Recursive call of the auxiliary method using the next iteration 
			 * of the linked list. Iterates the head to the next node and inputs 
			 * it as the parameter.
			 */
			getReverseListAux(newHead.next,reversal);
			/*
			 * Adds the head node data to the new linked list using the addToEnd 
			 * method. Since it is done after the recursive call, it adds in 
			 * reverse since it will all be counted at the end once the 
			 * recursive method finishes iterating. Also it adds to the end, 
			 * allowing the list to be reversed.
			 */
			reversal.addToEnd(newHead.data);
		}
		//Return to break.
		return;
	}
}