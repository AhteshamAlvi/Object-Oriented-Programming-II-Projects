package listClasses;

import java.util.*;


/**
 * Implements a generic sorted list using a provided Comparator. It extends
 * BasicLinkedList class.
 * 
 *  @author Dept of Computer Science, UMCP
 *  
 */

public class SortedLinkedList<T> extends BasicLinkedList<T> {
	//Creates the comparator reference.
	private Comparator<T> comparator;

	/*
	 * Constructor for the new sorted list that calls the comparator as a 
	 * parameter.
	 */
	public SortedLinkedList(Comparator<T> comparator) {
		//Calls the super class.
		super();
		//Creates the comparator reference.
		this.comparator = comparator;
		//Sets the head node to null.
		head = null;
	}
	
	//Sorted list add method that adds the new elements in the desired order.
	public SortedLinkedList<T> add​(T element) {
		//creates a new node with the inputed element.
		Node newNode = new Node(element);
		
		/*
		 * Checks if the head is null meaning the list is empty, or if the 
		 * first element is already ahead of the desired comparison.
		 */
		if(head == null || this.comparator.compare(element, head.data) <= 0) {
			//If so, adds the new node as the first element of the list.
			newNode.next = head;
			//Sets the head to the new node.
			head = newNode;
			//Increments the list size and returns a reference to the object.
			listSize++;
			return this;
		}
		
		//Creates a current reference to the head node.
		Node curr = head;
		/*
		 * Iterates through the list, checking if the end of the list is reached
		 * or the comparator has said that the new node has reached its place
		 * on the comparison with the other nodes (checks if the value is
		 * greater than or equal to 0.
		 */
		while(curr.next != null && this.comparator
				.compare(element,curr.next.data) >= 0) {
			//until then, iterates through the list
			curr = curr.next;
		}
		/*
		 * Once out of the list, adds the new node into the list by making its 
		 * next reference the one after the current reference, then sets the 
		 * current reference's next reference to the new node.
		 */
		newNode.next = curr.next;		
		curr.next = newNode;
		/* 
		 * Increments the list size and returns a reference to the current 
		 * object.
		 */
		listSize++;
		return this;
	}
		
	/* 
	 * Calls the super classes remove method to remove the target node from the 
	 * list using the target data and the comparator, then returns a reference 
	 * to the current object.
	 */
	public SortedLinkedList<T> remove​(T targetData) {
		super.remove​(targetData, comparator);
		return this;
	}
	
	/*
	 * Throws an UnsupportedOperationException if the addToEnd method is called 
	 * on a sortedList.
	 */
	public BasicLinkedList<T> addToEnd​(T data) {
		throw new UnsupportedOperationException(
				"Invalid operation for sorted list.");
	}

	/*
	 * Throws an UnsupportedOperationException if the addToFront method is 
	 * called on a sortedList.
	 */
	public BasicLinkedList<T> addToFront​(T data) {
		throw new UnsupportedOperationException(
				"Invalid operation for sorted list.");
	}
}