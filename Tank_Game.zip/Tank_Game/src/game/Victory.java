package game;
//Omar and Ahtesham

// this is an interface 
// we use this to display the winning screen
public interface Victory {
	
	public void victoryScreen(String winner);
}