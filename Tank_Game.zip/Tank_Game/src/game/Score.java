package game;
//Omar and Ahtesham

public interface Score {
	
	public int increaseScore(int score);
}
