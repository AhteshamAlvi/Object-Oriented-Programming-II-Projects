package model;

import java.util.ArrayList;

public class ParagraphElement extends TagElement implements Element {
	private ArrayList<Element> paragraph;
	
	public ParagraphElement(String attributes) {
		super("p", true, null, attributes);
		this.paragraph = new ArrayList<>();
	}
	
	//adds item to the paragraph ArrayList
	public void addItem(Element item) {
		paragraph.add(item);
	}
	
	@Override
	public String genHTML(int indentation) {
		String space = "";
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		
		String pars = space + this.getStartTag() + "\n";
		for(int i = 0; i < this.paragraph.size(); i++) {
			pars += space + this.paragraph.get(i).genHTML(indentation) + "\n";
		}
		pars += space + this.getEndTag();
		
		return pars;
	}
}
