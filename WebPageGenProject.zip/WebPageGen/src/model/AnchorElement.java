package model;

public class AnchorElement extends TagElement implements Element {
	private String url, linkText;
	
	public AnchorElement(String url, String linkText, String attributes) {
		super("a", true, null, attributes);
		this.linkText = linkText;
		this.url = url;
	}
	
	public String getLinkText() {
		return this.linkText;
	}
 
	public String getUrlText() {
		return this.url;
	}
	
	@Override
	public String getStartTag() {
		if(!enable) {
			return "<a href=\"" + this.getUrlText() + "\">";
		}
		return "<a id=\"" + this.getStringId() + "\" href=\"" + 
				this.getUrlText() + "\">";
	}

	@Override
	public String genHTML(int indentation) {
		String space = "";
		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		return space + this.getStartTag() + this.getLinkText() + 
				this.getEndTag();
	}
}
