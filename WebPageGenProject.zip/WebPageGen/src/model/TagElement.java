package model;

import java.util.ArrayList;

public class TagElement implements Element {
	private String tagName, attributes;
	private boolean endTag;
	private Element content;
	private int id;
	public static boolean enable = true;
	public static int uniqueId = 1;

	public TagElement(String tagName, boolean endTag, Element content, 
			String attributes) {
		this.tagName = tagName;
		this.endTag = endTag;
		this.content = content;
		this.attributes = attributes;
		this.id = uniqueId++;
		
	}
	
	public static void enableId(boolean choice) {
		enable = choice;
		
	}
	
	public String getEndTag() {
		if(!endTag) {
			return "";
		}
		return "</" + tagName + ">";
	}

	public int getId() {
		return this.id;
	}
	
	//Gives the starting tag for the HTML
	public String getStartTag() {
		String tag = "";
		
		if(!enable && attributes == null) {
			tag = "<" + tagName + ">";
		} else if(!enable && attributes != null) {
			tag = "<" + tagName + " " + attributes + ">";			
		} else if(enable && attributes == null) {
			tag = "<" + tagName + " id=\"" + this.getStringId() + "\">";
		} else if(enable && attributes != null) {
			tag = "<" + tagName + " id=\"" + this.getStringId() + "\" " + 
					attributes + ">";
		}
		return tag;
	}
	
	
	public String getStringId() {
		return this.tagName + this.id;
	}
	
	public static void resetIds() {
		uniqueId = 1;
	}
	
	public void setAttributes​(String attributes) {
		this.attributes = attributes;
	}
	
	//Generates the HTML output in text
	@Override
	public String genHTML(int indentation) {
		String space = "";
		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		return space + this.getStartTag() + this.content.genHTML(0) +
				this.getEndTag();
	}

}
