package model;

public class TextElement implements Element {
	public String text;
	
	
	public TextElement(String text) {
		this.text = text;
	}
	
	@Override
	public String genHTML(int indentation) {
		String space = "";
		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		return space + this.text;
	}
}
