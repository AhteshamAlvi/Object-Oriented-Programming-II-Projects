package model;

import java.util.ArrayList;

public class WebPage implements Comparable<WebPage>{
	private static boolean enable;
	private String title;
	private ArrayList<Element> pages;

	public WebPage(String title) {
		this.title = title;
		this.pages = new ArrayList<>();
	}
	
	//adds element to pages
	public int addElement​(Element element) {
		if(!(element instanceof Element)) {
			return -1;
		}
		this.pages.add(element);
		return ((TagElement) element).getId();
	}

	//writes webpage HTML to specified file
	public void writeToFile​(String filename, int indentation) {
		Utilities.writeToFile(filename, this.getWebPageHTML​(indentation));
	}
	
	//generates HTML for webpage
	public String getWebPageHTML​(int indentation) {
		String space = "";		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		String page = "";
		page = "<!doctype html>\n"
				+ "<html>\n"
				+ space + "<head>\n"
				+ space + space + "<meta charset=\"utf-8\"/>\n"
				+ space + space + "<title>" + this.title + "</title>\n"
				+ space + "</head>\n"
				+ space + "<body>\n";
				
		for(int i = 0; i < this.pages.size(); i++) {
			page += this.pages.get(i).genHTML(indentation) + "\n";
		}
		page += space + "</body>\n</html>";
		return page;
	}
	
	//finds element in pages based on id
	public Element findElem​(int id) {
		for(int i = 0; i < this.pages.size(); i++) {
			if(((TagElement) this.pages.get(i)).getId() == id) {
				return this.pages.get(i);
			}
		}
		return null;
	}
	
	//returns stats on the tables
	public String stats() {
		int lists = 0, paras = 0, tables = 0;
		double tableUtil = 0;
		for(int i = 0; i < this.pages.size(); i++) {
			if(this.pages.get(i) instanceof ListElement) {
				lists++;
			} else if(this.pages.get(i) instanceof ParagraphElement) {
				paras++;
			} else if(this.pages.get(i) instanceof TableElement) {
				tables++;
				tableUtil += ((TableElement)this.pages.get(i))
						.getTableUtilization();
			}
		}
		return "List Count: "+ lists +"\nParagraph Count: " + paras 
				+ "\nTable Count: " + tables + "\nTableElement Utilization: " 
				+ (tableUtil/tables);
	}
	
	//stateic enable ID
	public static void enableId​(boolean choice) {
		enable = choice;
	}
	
	@Override
	public int compareTo(WebPage obj) {
		return this.compareTo(obj);
	}
}
