package model;

public class TableElement extends TagElement implements Element {
	private Element[][] table;

	public TableElement(int rows, int cols, String attributes) {
		super("table", true, null, attributes);
		this.table = new Element[rows][cols];
	}
		
	public void addItem(int rowIndex, int colIndex, Element item) {
		table[rowIndex][colIndex] = item;
	}
	
	//gives number of table slots being used
	public double getTableUtilization(){
		double num = 0, count = 0;
		
		for(int i = 0; i < table.length; i++) {
			for(int j = 0; j < table[i].length; j++) {
				num++;
				if(table[i][j] != null) {
					count++;
				}
			}
		}
		return (count/num)*100;
	}
	
	@Override
	public String genHTML(int indentation) {
		String space = "";		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		
		String table = space + this.getStartTag() + "\n";
		
		for(int i = 0; i < this.table.length; i++) {
			table += space + "   <tr>";
			for(int j = 0; j < this.table[i].length; j++) {
				table += "<td>";
				if(this.table[i][j] != null) {
					table += this.table[i][j].genHTML(0);
				}
				table += "</td>";
			}
			table += "</tr>\n";
		}
		table += space + this.getEndTag();
		return table;
	}
}
