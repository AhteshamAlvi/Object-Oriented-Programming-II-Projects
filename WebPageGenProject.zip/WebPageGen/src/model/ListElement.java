package model;

import java.util.ArrayList;

public class ListElement extends TagElement implements Element {
	private boolean ordered;
	private ArrayList<Element> items;
	private String attributes;
	
	public ListElement(boolean ordered, String attributes) {
		super(null, true, null, attributes);
		this.ordered = ordered;
		this.items = new ArrayList<>();
		this.attributes = attributes;
	}
	
	public void addItem(Element element) {
		items.add(element);
	}
	
	@Override
	public String getStartTag() {
		String tag = "";
		
		if(!enable && ordered) {
			tag = "<ol";
		} else if(!enable && !ordered) {
			tag = "<ul";			
		} else if(enable && ordered) {
			tag = "<ol id=\"ol" + this.getId() + "\"";
		} else if(enable && !ordered) {
			tag = "<ul id=\"ul" + this.getId() + "\"";
		}
		
		if(attributes != null) {
			tag += " " + attributes;
		}
		return tag + ">";
	}
	
	//returns either ul or ol for the endtag
	@Override
	public String getEndTag() {
		if(ordered) {
			return  "</ol>";
		}
		return "</ul>";
	}
	
	@Override
	public String genHTML(int indentation) {
		String space = "";		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		
		String list = space + this.getStartTag() + "\n";
		for(int i = 0; i < this.items.size(); i++) {
			list += space + "   " + "<li>\n";
			list += space + "      " + this.items.get(i).genHTML(indentation) + 
					"\n";
			list += space + "   " + "</li>\n";
		}
		list += space + this.getEndTag();
		return list;
	}
}
