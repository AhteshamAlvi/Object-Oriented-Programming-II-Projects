package model;

public class ImageElement extends TagElement implements Element {
	private String imageURL, alt;
	private int width, height;

	public ImageElement(String imageURL, int width, int height, String alt, 
			String attributes) {
		super("img", false, null, attributes);
		
		this.imageURL = imageURL;
		this.width = width;
		this.height = height;
		this.alt = alt;
	}
	
	public String getImageURL() {
		return this.imageURL;
	}
	//ovverrites the starttag from TagElements
	@Override
	public String getStartTag() {
		String tag = "";
		
		if(!enable) {
			tag = "<img src=\"" + this.getImageURL() + "\" width=\"" + 
					this.width + "\" height=\"" + this.height + "\" alt=\"" + 
					this.alt + "\">";
		} else {
			tag = "<img id=\"" + this.getStringId() + "\" src=\"" + 
					this.getImageURL() + "\" width=\"" + this.width + 
					"\" height=\"" + this.height + "\" alt=\"" + this.alt + 
					"\">";
		}
		return tag;
	}
	
	@Override
	public String genHTML(int indentation) {
		String space = "";
		
		for(int i = 0; i < indentation; i++) {
			space += " ";
		}
		return space + this.getStartTag() + this.getEndTag();
	}
	
}
